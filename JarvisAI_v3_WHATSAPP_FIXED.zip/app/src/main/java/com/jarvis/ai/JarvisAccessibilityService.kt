package com.jarvis.ai

import android.accessibilityservice.AccessibilityService
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class JarvisAccessibilityService : AccessibilityService() {
    companion object {
        var instance: JarvisAccessibilityService? = null
        val protectedApps = setOf("com.instagram.android")
    }

    private var queuedMessage: String? = null
    private var queuedChat: String? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && protectedApps.contains(pkg)) {
            handler.post { Toast.makeText(this, "Sir, protected app detected.", Toast.LENGTH_SHORT).show() }
        }
        if (pkg == "com.whatsapp") {
            queuedChat?.let { target ->
                queuedChat = null
                handler.postDelayed({ openWhatsAppChat(target) }, 700)
            }
            queuedMessage?.let { message ->
                handler.postDelayed({
                    typeIntoFocusedField(message)
                    queuedMessage = null
                }, 1200)
            }
        }
    }

    fun queueWhatsAppMessage(text: String?) {
        queuedMessage = text
        if (text == null) return
        packageManager.getLaunchIntentForPackage("com.whatsapp")?.let { startActivity(it) }
    }

    fun openWhatsAppLockedChats(): Boolean {
        val intent = packageManager.getLaunchIntentForPackage("com.whatsapp") ?: return false
        startActivity(intent)
        handler.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            findNode(root, listOf("Locked chats", "Locked Chats", "लॉक किए गए चैट", "लॉक्ड चैट"))
                ?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }, 900)
        return true
    }

    fun queueWhatsAppChat(contact: String?): Boolean {
        val target = contact?.trim()?.ifBlank { null } ?: return false
        queuedChat = target
        packageManager.getLaunchIntentForPackage("com.whatsapp")?.let {
            startActivity(it)
            return true
        }
        queuedChat = null
        return false
    }

    private fun openWhatsAppChat(contact: String) {
        val root = rootInActiveWindow ?: return
        val search = findNode(root, listOf("Search", "search", "खोजें", "खोज"))
        if (search != null) {
            search.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            handler.postDelayed({
                val r = rootInActiveWindow ?: return@postDelayed
                val input = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    ?: findEditable(r)
                input?.let {
                    val args = android.os.Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, contact)
                    }
                    it.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    handler.postDelayed({
                        val resultRoot = rootInActiveWindow ?: return@postDelayed
                        findNode(resultRoot, listOf(contact))?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }, 700)
                }
            }, 450)
        } else {
            findNode(root, listOf(contact))?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
    }

    private fun findNode(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        for (label in labels) {
            root.findAccessibilityNodeInfosByText(label).firstOrNull()?.let { return it }
        }
        return null
    }

    private fun findEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (root.isEditable) return root
        for (i in 0 until root.childCount) {
            root.getChild(i)?.let { child ->
                findEditable(child)?.let { return it }
            }
        }
        return null
    }

    private fun typeIntoFocusedField(text: String) {
        val root = rootInActiveWindow ?: return
        val focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val args = android.os.Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun openRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun lockDevice(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, JarvisDeviceAdminReceiver::class.java)
        return if (dpm.isAdminActive(admin)) { dpm.lockNow(); true } else false
    }

    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }
}
