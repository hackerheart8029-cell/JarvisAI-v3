package com.jarvis.ai

import android.app.*
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class JarvisVoiceService : Service(), TextToSpeech.OnInitListener {
    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private val handler = Handler(Looper.getMainLooper())
    private var listening = false
    private var speaking = false
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        createNotification()
        tts = TextToSpeech(this, this)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(JarvisRecognitionListener(
            onText = { handle(it) },
            onReady = { listening = true },
            onError = { restartListening(450) }
        ))
        restartListening(300)
    }

    private fun createNotification() {
        val channel = NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val stop = PendingIntent.getService(this, 2, Intent(this, JarvisVoiceService::class.java).apply { action = "STOP" }, PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is active")
            .setContentText("Wake word: Hey Jarvis")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
        startForeground(7, n)
    }

    private fun restartListening(delay: Long = 300) {
        if (stopping) return
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (!stopping && !speaking) {
                try {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    }
                    recognizer.startListening(i)
                    listening = true
                } catch (_: Exception) { restartListening(1000) }
            }
        }, delay)
    }

    private fun handle(raw: String) {
        listening = false
        val text = raw.lowercase(Locale.getDefault()).trim()
        if (!(text.contains("jarvis") || text.contains("जार्विस"))) { restartListening(); return }
        val command = text.replace("hey jarvis", "").replace("jarvis", "").replace("जार्विस", "").trim()
        if (command.isBlank()) speak("Yes sir, boliye.")
        else speak(JarvisCommandEngine.execute(this, command))
    }

    private fun speak(s: String) {
        speaking = true
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        handler.postDelayed({ speaking = false; restartListening(250) }, (s.length * 55L).coerceIn(900L, 5000L))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopping = true; stopSelf() }
        return START_STICKY
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
            tts.setPitch(1.08f)
            tts.setSpeechRate(.92f)
        }
    }

    override fun onDestroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        if (::recognizer.isInitialized) recognizer.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
