package com.jarvis.ai

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.*
import android.content.SharedPreferences
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        status = TextView(this).apply {
            text = "JARVIS v3\n\nHey Jarvis • Hindi voice • App control • Accessibility automation"
            textSize = 19f
        }
        box.addView(status)

        button(box, "1. Enable Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button(box, "2. Allow Phone Lock") { requestDeviceAdmin() }
        button(box, "3. Start Hey Jarvis") {
            val i = Intent(this, JarvisVoiceService::class.java)
            startForegroundService(i)
            status.text = "JARVIS ACTIVE\n\nSay: Hey Jarvis + command"
        }
        button(box, "Stop Jarvis") {
            stopService(Intent(this, JarvisVoiceService::class.java))
            status.text = "JARVIS STOPPED"
        }
        button(box, "Open Accessibility Settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button(box, "Open Wi-Fi Settings") { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        val gfLabel = TextView(this).apply {
            text = "\nWhatsApp girlfriend chat name"
            textSize = 15f
        }
        box.addView(gfLabel)
        val gfInput = EditText(this).apply {
            hint = "WhatsApp contact name"
            setSingleLine(true)
            setText(getSharedPreferences("jarvis", MODE_PRIVATE).getString("gf_chat", ""))
        }
        box.addView(gfInput)
        button(box, "Save GF WhatsApp Chat") {
            getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("gf_chat", gfInput.text.toString().trim()).apply()
            status.text = "GF WhatsApp chat name saved."
        }

        val examples = TextView(this).apply {
            text = """
Examples
• Hey Jarvis, YouTube kholo
• Hey Jarvis, Instagram kholo
• Hey Jarvis, WhatsApp kholo
• Hey Jarvis, search Transformers Prime
• Hey Jarvis, back / home / recent apps
• Hey Jarvis, notifications dikhao
• Hey Jarvis, phone lock
• Hey Jarvis, meri gf ki WhatsApp chat kholo
• Hey Jarvis, WhatsApp me [contact] ki chat kholo
• Hey Jarvis, message bhejo: hello
""".trimIndent()
            textSize = 15f
        }
        box.addView(examples)
        setContentView(box)
    }

    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } })
    }

    private fun requestDeviceAdmin() {
        val component = ComponentName(this, JarvisDeviceAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Jarvis ko voice command se phone lock karne ke liye Device Admin permission chahiye.")
        }
        startActivity(intent)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
            tts.setPitch(1.08f)
            tts.setSpeechRate(.92f)
        }
    }
    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}
