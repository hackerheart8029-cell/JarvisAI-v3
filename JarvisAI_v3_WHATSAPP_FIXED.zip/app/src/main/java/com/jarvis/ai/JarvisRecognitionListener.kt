package com.jarvis.ai

import android.os.Bundle
import android.speech.RecognitionListener

class JarvisRecognitionListener(
    val onText: (String) -> Unit,
    val onReady: () -> Unit,
    val onError: () -> Unit
) : RecognitionListener {
    override fun onReadyForSpeech(params: Bundle?) = onReady()
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) = onError()
    override fun onResults(results: Bundle?) {
        results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()?.let(onText) ?: onError()
    }
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
