# JARVIS AI v3

This build focuses on phone + WhatsApp assistance. Room/smart-appliance control is intentionally not included.

## Included
- “Hey Jarvis” speech-recognition wake-word gating
- Friendly Hindi female-style TTS tuning
- Foreground microphone service
- Open YouTube, Instagram, WhatsApp, Chrome and Camera
- Google/search commands
- Home, Back, Recents and Notifications through Accessibility
- Device-approved phone lock
- WhatsApp chat navigation by contact name
- WhatsApp Locked Chats screen navigation; PIN/Secret Code remains manual and is never captured or bypassed
- Optional saved “girlfriend WhatsApp chat name” alias
- WhatsApp message typing foundation; Jarvis does not silently press Send

## Setup
1. Allow microphone permission.
2. Allow notification permission if Android asks.
3. Enable Jarvis under Accessibility settings.
4. Start Jarvis.
5. If you want “meri gf ki WhatsApp chat kholo”, enter the exact WhatsApp contact name in the app and save it.

## Example commands
- Hey Jarvis, YouTube kholo
- Hey Jarvis, WhatsApp kholo
- Hey Jarvis, WhatsApp Locked Chats kholo
- Hey Jarvis, meri gf ki WhatsApp chat kholo
- Hey Jarvis, WhatsApp me [contact] ki chat kholo
- Hey Jarvis, search Transformers Prime
- Hey Jarvis, back / home / recent apps
- Hey Jarvis, notifications dikhao
- Hey Jarvis, phone lock
- Hey Jarvis, message bhejo: hello

## Android limitations
Accessibility must be explicitly enabled by the user. WhatsApp UI can change between versions, so chat navigation may need adjustment if WhatsApp changes its accessibility labels. Android security is not bypassed.

No room-control or smart-appliance features are part of this build.
