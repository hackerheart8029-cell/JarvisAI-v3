package com.jarvis.ai

import android.app.admin.DeviceAdminReceiver

class JarvisDeviceAdminReceiver : DeviceAdminReceiver()
