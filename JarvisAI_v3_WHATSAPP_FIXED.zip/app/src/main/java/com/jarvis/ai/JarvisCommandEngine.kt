package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import java.util.Locale

/** Central command router. It deliberately uses public Android intents/APIs and
 * the explicitly enabled AccessibilityService; it does not bypass Android security. */
object JarvisCommandEngine {
    fun execute(context: Context, raw: String): String {
        val original = raw.trim()
        val c = original.lowercase(Locale.getDefault())

        if (c.contains("youtube") && isOpen(c)) return openPackage(context, "com.google.android.youtube", "YouTube")
        if (c.contains("instagram") && isOpen(c)) return openPackage(context, "com.instagram.android", "Instagram")
        if (c.contains("whatsapp") && isOpen(c)) return openPackage(context, "com.whatsapp", "WhatsApp")
        if ((c.contains("chrome") || c.contains("browser")) && isOpen(c)) return openPackage(context, "com.android.chrome", "Chrome")
        if (c.contains("settings") && isOpen(c)) { context.startActivity(Intent(Settings.ACTION_SETTINGS)); return "Settings khol raha hoon sir." }
        if ((c.contains("wifi") || c.contains("wi-fi")) && (c.contains("settings") || c.contains("kholo") || c.contains("open"))) {
            context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Wi-Fi settings khol raha hoon sir."
        }
        if ((c.contains("bluetooth") || c.contains("ब्लूटूथ")) && (c.contains("settings") || c.contains("kholo") || c.contains("open"))) {
            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Bluetooth settings khol raha hoon sir."
        }

        if (c.contains("brightness") || c.contains("screen bright") || c.contains("display bright")) {
            context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)); return "Display settings khol raha hoon sir."
        }
        if (c.contains("volume") && (c.contains("settings") || c.contains("control") || c.contains("kholo") || c.contains("open"))) {
            context.startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)); return "Sound settings khol raha hoon sir."
        }

        if (c.contains("google") && isOpen(c)) {
            openUrl(context, "https://www.google.com"); return "Google khol raha hoon sir."
        }
        if (c.startsWith("search ") || c.contains(" search ")) {
            val q = original.replace(Regex("(?i)\\b(hey\\s+)?jarvis\\b"), "").replaceFirst(Regex("(?i)^\\s*search\\s*"), "").trim()
            if (q.isNotBlank()) { openUrl(context, "https://www.google.com/search?q=" + Uri.encode(q)); return "Search kar raha hoon sir." }
        }

        if (c.contains("home") || c.contains("ghar screen")) {
            return if (JarvisAccessibilityService.instance?.goHome() == true) "Home screen par aa gaya sir." else "Sir, Accessibility enable karni hogi."
        }
        if (c.contains("back") || c.contains("peeche")) {
            return if (JarvisAccessibilityService.instance?.goBack() == true) "Back kar diya sir." else "Sir, Accessibility enable karni hogi."
        }
        if (c.contains("recent") || c.contains("recents")) {
            return if (JarvisAccessibilityService.instance?.openRecents() == true) "Recent apps khol raha hoon sir." else "Sir, Accessibility enable karni hogi."
        }
        if (c.contains("notification") && (c.contains("open") || c.contains("dikhao") || c.contains("dekho"))) {
            return if (JarvisAccessibilityService.instance?.openNotifications() == true) "Notifications khol raha hoon sir." else "Sir, Accessibility enable karni hogi."
        }

        if (c.contains("lock phone") || c.contains("phone lock") || c.contains("phone ko lock")) {
            return if (JarvisAccessibilityService.instance?.lockDevice() == true) "Phone lock kar raha hoon sir." else "Sir, device-lock ke liye Android ka approved device-owner setup chahiye."
        }

        if (c.contains("whatsapp") && (c.contains("locked chat") || c.contains("locked chats") || c.contains("lock chat") || c.contains("locked chats kholo"))) {
            return if (JarvisAccessibilityService.instance?.openWhatsAppLockedChats() == true) {
                "WhatsApp Locked Chats khol raha hoon sir. PIN ya Secret Code aapko khud enter karna hoga."
            } else "Sir, WhatsApp installed nahi hai ya Accessibility enable nahi hai."
        }

        if (c.contains("whatsapp") && (c.contains("gf") || c.contains("girlfriend") || c.contains("meri gf") || c.contains("meri girlfriend")) && (c.contains("chat") || c.contains("baat") || c.contains("khol"))) {
            val name = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("gf_chat", null)
            if (name.isNullOrBlank()) return "Sir, pehle Jarvis me apni girlfriend ka WhatsApp chat name save kar dijiye."
            return if (JarvisAccessibilityService.instance?.queueWhatsAppChat(name) == true) "WhatsApp me $name ki chat khol raha hoon sir." else "Sir, WhatsApp installed nahi hai ya Accessibility enable nahi hai."
        }

        val chatMatch = Regex("(?i)whatsapp.*(?:chat|baat).*?(?:of|ki|ka|ke)?\\s+(.+?)\\s*(?:khol|open|dikhao)$").find(original)
            ?: Regex("(?i)(?:chat|baat).*?(?:of|ki|ka|ke)?\\s+(.+?)\\s*(?:khol|open|dikhao)$").find(original)
        if (chatMatch != null) {
            val target = chatMatch.groupValues.getOrNull(1)?.trim()?.removeSuffix("?")
            if (!target.isNullOrBlank()) {
                return if (JarvisAccessibilityService.instance?.queueWhatsAppChat(target) == true) "WhatsApp me $target ki chat khol raha hoon sir." else "Sir, WhatsApp installed nahi hai ya Accessibility enable nahi hai."
            }
        }

        if (c.contains("message") || c.contains("msg")) {
            val msg = extractMessage(original)
            if (msg != null) {
                JarvisAccessibilityService.instance?.queueWhatsAppMessage(msg)
                return "Sir, WhatsApp khol diya hai. Send karne se pehle confirmation rakha hai."
            }
            return "Sir, message kis text ka bhejna hai?"
        }

        if (c.contains("open camera") || c.contains("camera kholo") || c == "camera") {
            context.startActivity(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return "Camera khol raha hoon sir."
        }
        if (c.contains("torch") || c.contains("flashlight")) {
            return "Sir, torch control ke liye device-specific Camera2 access chahiye; main abhi uska safe toggle add karne layak architecture rakh raha hoon."
        }

        if (c.contains("din kaisa") || c.contains("day kaisa")) return "Main yahin hoon sir. Aap bataiye, aaj ka din kaisa gaya?"
        if (c.contains("hello") || c == "hi" || c == "hey") return "Yes sir. Boliye."
        if (c.contains("who are you") || c.contains("tum kaun")) return "Main Jarvis hoon sir — aapka voice assistant."
        if (c.contains("thank")) return "Anytime sir."

        return "Sir, command samajh aayi. Is action ke liye abhi specific Android integration configure nahi hai."
    }

    private fun isOpen(c: String) = c.contains("kholo") || c.contains("open") || c.contains("chalao") || c.contains("start")

    private fun extractMessage(raw: String): String? {
        val r = raw.trim()
        val m = Regex("(?i)\\b(message\\s+(bhejo|karo)|msg\\s+(bhejo|karo))\\b[:\\-]?\\s*(.*)$").find(r)
        return m?.groupValues?.getOrNull(4)?.trim()?.ifBlank { null }
    }

    private fun openPackage(context: Context, pkg: String, name: String): String {
        val i = context.packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i); return "$name khol raha hoon sir." }
        Toast.makeText(context, "$name installed nahi hai.", Toast.LENGTH_SHORT).show()
        return "Sir, $name installed nahi hai."
    }

    private fun openUrl(context: Context, url: String) = context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
